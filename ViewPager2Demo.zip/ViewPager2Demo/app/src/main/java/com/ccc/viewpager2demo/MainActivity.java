package com.ccc.viewpager2demo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private List<String> titles;
    private TabLayoutMediator tabLayoutMediator;
    private ViewPager2 vp2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vp2 = findViewById(R.id.page);
        tabLayout = findViewById(R.id.tabLayout);
        titles = new ArrayList<>();

        titles.add("title0");
        titles.add("title1");
        titles.add("title2");

        TabLayout.Tab tab1 = tabLayout.newTab();
        tab1.setCustomView(R.layout.tab_item);

        //创建并添加 Tab
        TextView tvTitle = tab1.getCustomView().findViewById(R.id.tvTitle);
        tvTitle.setText("带图标");
        tabLayout.addTab(tab1);
        TabLayout.Tab tab2 = tabLayout.newTab().setText("自定义标题1");
        tabLayout.addTab(tab2);
        TabLayout.Tab tab3 = tabLayout.newTab().setText("自定义标题2");
        tabLayout.addTab(tab3);

        //创建 Adapter
        TabAdapter tabAdapter = new TabAdapter(MainActivity.this, titles);
        vp2.setAdapter(tabAdapter);

//        //tabLayout 和 vp2 联动
//        tabLayoutMediator = new TabLayoutMediator(tabLayout, vp2, new TabLayoutMediator.TabConfigurationStrategy() {
//            @Override
//            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
//                tab.setText(titles.get(position));
//            }
//        });
//        //绑定
//        tabLayoutMediator.attach();

        //原始
        //tabLayout的事件监听
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Log.d("test",tab.getPosition()+"        +++++++++++++");
                vp2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        //vp2的事件监听
        vp2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                tabLayout.selectTab(tabLayout.getTabAt(position));
            }
        });


    }

    //解绑
    @Override
    protected void onDestroy() {
        if (tabLayoutMediator != null) {
            tabLayoutMediator.detach();
        }
        super.onDestroy();
    }
}
