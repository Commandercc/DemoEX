package com.ccc.viewpager2demo;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import java.util.Random;

/**
 * @author ch
 * @date 2020/1/11 11:08
 * @desc
 */
public class DemoFragment extends Fragment {

    private TextView tvDemo;
    private String title;

    public DemoFragment(String title) {
        this.title = title;
    }

    public DemoFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fm_demo, container, false);
        tvDemo = view.findViewById(R.id.tvDemo);
        tvDemo.setBackgroundColor(Color.YELLOW);
        tvDemo.setText(title);
        return view;
    }

}
