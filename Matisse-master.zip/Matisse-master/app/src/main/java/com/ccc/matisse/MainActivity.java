package com.ccc.matisse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ImageView;
import com.ccc.adapter.PhotoSelAdapter;
import com.ccc.util.GlideLoadEngine;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.CaptureStrategy;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ImageView mView;
    private RecyclerView mRecyclerView;
    private PhotoSelAdapter adapter;
    private List<String> mPhotos;
    //声明一个权限数组
    private String[] permissions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
    };
    private List<String> mPermissionList = new ArrayList<>();
    //定义一个权限请求码
    private static final int PERMISSION_REQUEST = 1;
    //定义一个图片选择后的请求码
    private final int REQUEST_CODE_CHOOSE_PHOTO_ALBUM = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initPermission(); //申请权限
        initview();     //初始化空间
    }

    private void initview() {

        mPhotos=new ArrayList<>();
        mRecyclerView=findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this ,3));  //设置布局 每行3列
        adapter = new PhotoSelAdapter(mPhotos);
        System.out.println(mPhotos.size());
        mRecyclerView.setAdapter(adapter);
        //  + 号点击事件
        adapter.setOnItemClickListener(new PhotoSelAdapter.OnItemClickListener() {
            @Override
            public void onPhotoClick(int position) {
                if (mPhotos.get(position).equals(PhotoSelAdapter.mPhotoAdd)) {
                    selectPic();
                    mPhotos.remove(position);
                } else {
                    mPhotos.remove(PhotoSelAdapter.mPhotoAdd);
                }
            }

            @Override
            public void onDelete(int position) {
                mPhotos.remove(position);
                adapter.setPhotos(mPhotos);
            }
        });
    }
    private void initPermission() {
        mPermissionList.clear();
        /**
         * 判断哪些权限未授予
         */
        for (int i = 0; i < permissions.length; i++) {
            if (ContextCompat.checkSelfPermission(this, permissions[i]) != PackageManager.PERMISSION_GRANTED) {
                mPermissionList.add(permissions[i]);
            }
        }
        /**
         * 判断是否为空
         */
        if (mPermissionList.isEmpty()) {
            //未授予的权限为空，表示都授予了
        } else {
            //请求权限方法
            String[] permissions = mPermissionList.toArray(new String[mPermissionList.size()]);//将List转为数组
            //调用requestPermissions（）向系统申请权限
            //该方法接收3个参数，第一个是activity实例，第二个是一个String数组，第三个是请求码
            ActivityCompat.requestPermissions(MainActivity.this, permissions, PERMISSION_REQUEST);
        }
    }
    /**
     * 响应授权
     * 这里不管用户是否拒绝，都进入首页，不再重复申请权限
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST:
                break;
            default:
                break;
        }
    }

    //相应图片选择
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("执行了外层");
        System.out.println(mPhotos.size());
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CHOOSE_PHOTO_ALBUM && resultCode == RESULT_OK) {
            System.out.println("执行了内层");
            //图片路径
            //eg: /storage/emulated/0/Pictures/Touches/520190821115327-1.png
            List<String> pathList = Matisse.obtainPathResult(data);
            System.out.println(pathList.size());
            for (String imgpath : pathList) {
                //System.out.println(imgpath); //测试地址
                mPhotos.add(imgpath); //将图片地址放入声明的 mPhotos数组中
            }
        }
        adapter.setPhotos(mPhotos);
    }


    private void selectPic() {
        //直接用知乎Matisse 这里简单的用了一下
        Matisse.from(this)
                .choose(MimeType.ofImage(), false)
                .capture(true)  // 使用相机，和 captureStrategy 一起使用
                .captureStrategy(new CaptureStrategy(true, "com.ccc.matisse"))
                .theme(R.style.Matisse_Dracula)
                .countable(true)
                .maxSelectable(6) //最大选择6张图片
                .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                .thumbnailScale(0.87f)
                .imageEngine(new GlideLoadEngine())
                .forResult(REQUEST_CODE_CHOOSE_PHOTO_ALBUM);
    }

}
