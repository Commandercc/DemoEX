package com.ccc.util;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.ccc.config.UrlParams;
import com.ccc.matisse.R;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ContentUtil {

    /**
     * 加载photopicker图片
     */
    public static void loadImage(ImageView imageView, String url) {
        Glide.with(imageView.getContext())
                .load(url)
                .dontAnimate()
                .error(R.drawable.img_user)
                //.apply(RequestOptions.circleCropTransform())
                .into(imageView);
    }

}
