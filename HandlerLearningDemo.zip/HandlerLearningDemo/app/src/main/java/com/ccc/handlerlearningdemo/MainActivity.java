package com.ccc.handlerlearningdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextView;
    public Handler mHandler;

    // 自定义 类继承 Handler类 复写 handleMessage() 方法
//    class Mhandler extends Handler {
//        @Override
//        public void handleMessage(@NonNull Message msg) {
//            //根据不同线程发送过来的消息，执行不同的UI操作
//            //根据 Message 对象的what属性 标识不同的消息
//            switch (msg.what) {
//                case 1:
//                    mTextView.setText("执行了线程1的UI操作");
//                    break;
//                case 2:
//                    mTextView.setText("执行了线程2的UI操作");
//                    break;
//            }
//        }
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = findViewById(R.id.show);

        //在主线程中创建 Handler 实例 内部类方式
        //mHandler = new Mhandler();
        //匿名类方式
//        mHandler = new Handler() {
//            @Override
//            public void handleMessage(@NonNull Message msg) {
//                // 根据不同线程发送过来的消息，执行不同的UI操作
//                switch (msg.what) {
//                    case 1:
//                        mTextView.setText("执行了线程1的UI操作");
//                        break;
//                    case 2:
//                        mTextView.setText("执行了线程2的UI操作");
//                        break;
//                }
//            }
//        };

        /**
         *  handlemessage方式
         */

        //这里采用Thread类实现多线程演示
//        new Thread() {
//            @Override
//            public void run() {
//                try {
//                    sleep(3000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//
//                //创建所需的消息对象
//                Message msg = Message.obtain();
//                msg.what = 1; //消息标识
//                msg.obj = "A"; //消息内存存放
//
//                //在工作线程线程中，通过handler发送消息到消息队列中
//                mHandler.sendMessage(msg);
//
//            }
//        }.start(); //开启工作线程（同时启动了Handler）
//
//        //此处用两个工作线程演示
//
//        // 此处用2个工作线程展示
//        new Thread() {
//            @Override
//            public void run() {
//                try {
//                    Thread.sleep(6000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                // 通过sendMessage（）发送
//                // a. 定义要发送的消息
//                Message msg = Message.obtain();
//                msg.what = 2; //消息的标识
//                msg.obj = "B"; // 消息的存放
//                // b. 通过Handler发送消息到其绑定的消息队列
//                mHandler.sendMessage(msg);
//            }
//        }.start();

        /**
         *  post方式
         *
         */
        mHandler = new Handler();

        new Thread() {
            @Override
            public void run() {
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //通过post 发送
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        //指定操作UI内容
                        mTextView.setText("执行了线程1的UI操作");
                    }
                });
            }
        }.start();
    }


}
