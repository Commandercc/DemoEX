package com.ccc.searchviewdemo;

/**
 *  返回按键回调接口
 */
public interface bCallBack {
    void BackAction();
}
