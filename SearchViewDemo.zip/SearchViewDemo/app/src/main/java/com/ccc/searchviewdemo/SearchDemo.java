package com.ccc.searchviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SearchDemo extends AppCompatActivity {

    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_demo);

        searchView = findViewById(R.id.search_view);

        // 搜索接口回调
        searchView.setOnClickSearch(new ICallBack() {
            @Override
            public void SearchAction(String text) {
                System.out.println("我收到了"+text);
            }
        });

        //返回接口回调
        searchView.setOnClickBack(new bCallBack() {
            @Override
            public void BackAction() {
                finish();
            }
        });
    }
}
