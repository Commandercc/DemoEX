package com.ccc.searchviewdemo;

/**
 *   搜索按键回调接口
 */
public interface ICallBack {
    void SearchAction(String text);
}
