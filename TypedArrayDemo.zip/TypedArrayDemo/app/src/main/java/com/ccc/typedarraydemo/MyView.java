package com.ccc.typedarraydemo;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class MyView extends View {

    private Paint paint;

    public MyView(Context context) {
        super(context);
    }

    /**
     * context通过调用obtainStyledAttributes方法来获取一个TypeArray，然后由该TypeArray来对属性进行设置
     * obtainStyledAttributes方法有三个，我们最常用的是有一个参数的obtainStyledAttributes(int[] attrs)，其参数直接styleable中获得
     * TypedArray a = context.obtainStyledAttributes(attrs,R.styleable.MyView);
     * 调用结束后务必调用recycle()方法，否则这次的设定会对下次的使用造成影响
     */
    public MyView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();

        // R.styleable.MyView  MyView 就是我们刚才在attrs文件中定义的 declare-styleable 属性的 name
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.MyView);

        // 属性的格式 MyView_myColor  即declare-styleable 属性的 name 和 自定义属性名之间用 -（横杠）连接
        int textColor = typedArray.getColor(R.styleable.MyView_myColor, Color.BLUE);
        float textSize = typedArray.getDimension(R.styleable.MyView_myTextSize, 35);
        paint.setTextSize(textSize);
        paint.setColor(textColor);
        typedArray.recycle();
    }

    public MyView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawText("hello world!", 200, 200, paint);
    }
}
