package com.ccc.animationdemo1;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button anim;
    private Button btn_jump;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1.创建需要设置动画的视图 View
        anim = findViewById(R.id.btn);
        //2.创建动画对象 并传入设置的动画效果xml文件
        Animation translateAnimation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.anim_set);
        //3.播放动画
        anim.startAnimation(translateAnimation);



        //页面跳转
        btn_jump = findViewById(R.id.btn2);
        btn_jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.in_from_right,R.anim.out_to_left);

            }
        });
    }
}
