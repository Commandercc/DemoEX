package com.ccc.animationdmeo3.objectDemo;

import android.animation.TypeEvaluator;

//实现 TypeEvaluator 接口
public class PointEvaluator implements TypeEvaluator {
    @Override
    public Object evaluate(float fraction, Object startValue, Object endValue) {

        //将动画初始值 和 结束值 强制类型转换成 Point 类对象
        Point startPoint = (Point) startValue;
        Point endPoint = (Point) endValue;

        //根据 fraction 来计算当前动画的 x 和 y 的值   fraction 表示动画完成度
        float x = startPoint.getX() + fraction * (endPoint.getX() - startPoint.getX());
        float y = startPoint.getY() + fraction * (endPoint.getY() - startPoint.getY());

        //将计算后的坐标封装到一个新的 Point 对象中并返回
        Point point = new Point(x,y);
        return point;
    }
}
