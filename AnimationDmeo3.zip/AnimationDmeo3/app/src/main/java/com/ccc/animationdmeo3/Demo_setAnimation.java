package com.ccc.animationdmeo3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.animation.BounceInterpolator;
import android.widget.Button;
import android.widget.Toast;

public class Demo_setAnimation extends AppCompatActivity {

    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_set_animation);

        button = findViewById(R.id.btn_anim);

        // 组合动画

        float curx = button.getTranslationX();
        //平移动画
        ObjectAnimator translation = ObjectAnimator.ofFloat(button,"translationX",curx,500,curx);
        //旋转动画
        ObjectAnimator ratate = ObjectAnimator.ofFloat(button,"rotation",0f,360f);
        //透明度动画
        ObjectAnimator alpha = ObjectAnimator.ofFloat(button,"alpha",1f,0f,1f);

        //创建组合动画
        AnimatorSet animatorSet = new AnimatorSet();

        //根据需求组合动画
        animatorSet.play(translation).with(ratate).before(alpha);
        animatorSet.setDuration(6000);

        //启动动画
        animatorSet.start();

        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                Toast.makeText(Demo_setAnimation.this,"动画结束了",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });


        // 快捷使用
 /*
        //单个动画设置 将按钮变成透明状态
        button.animate().alpha(0f);
        //// 单个动画效果设置 & 参数设置
        button.animate().alpha(0f).setDuration(5000).setInterpolator(new BounceInterpolator());
        // 组合动画:将按钮变成透明状态再移动到(500,500)处
        button.animate().alpha(0f).translationX(500).alpha(1f);

  */

    }
}
