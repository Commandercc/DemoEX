package com.ccc.animationdmeo3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.widget.Button;

import java.util.zip.Inflater;

public class Demo_ObjectAnimator extends AppCompatActivity {

    private Button btn_alpha, btn_translate, btn_rotate, btn_scale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo__object_animator);

        btn_alpha = findViewById(R.id.btn_alpha);
        btn_translate = findViewById(R.id.btn_translate);
        btn_rotate = findViewById(R.id.btn_rotate);
        btn_scale = findViewById(R.id.btn_scale);

        //1. 透明度动画
        ObjectAnimator animator = ObjectAnimator.ofFloat(btn_alpha, "alpha", 1f, 0f, 1f);
        // 表示的是:
        // 动画作用对象是btn_alpha
        // 动画作用的对象的属性是 透明度alpha  如果输入了不存在的属性 会出现提示
        // 动画效果是:常规 - 全透明 - 常规
        animator.setDuration(5000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.start();

        //2.旋转动画
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(btn_rotate, "rotation", 0f, 360f);
        // 表示的是:
        // 动画作用对象是btn_rotate
        // 动画作用的对象的属性是  旋转rotation
        // 动画效果是:0 - 360
        animator1.setDuration(5000);
        animator1.setRepeatCount(ValueAnimator.INFINITE);
        animator1.start();

        //3.平移
        float curTranslationX = btn_translate.getTranslationX(); //获取按钮当前位置
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(btn_translate, "translationX", curTranslationX, 300, curTranslationX);
        // 表示的是:
        // 动画作用对象是btn_translate
        // 动画作用的对象的属性是X轴平移（在Y轴上平移同理，采用属性"translationY")
        // 动画效果是:从当前位置 向右平移300 再平移到初始位置
        // 再例如 ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "translationY", 0, 200, -100,0);
        // 则表示指定的移动距离是（0, 200, -200,0），所以控件会从自身所有位置向右移动 200 像素，然后再移动到距离原点-200 的位置，最后回到原点
        animator2.setDuration(5000);
        animator2.setRepeatCount(ValueAnimator.INFINITE);
        animator2.start();

        //4.缩放
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(btn_scale, "ScaleX", 1f, 3f, 1f);
        // 表示的是:
        // 动画作用对象是btn_scale
        // 动画作用的对象的属性是X轴缩放
        // 动画效果是:放大到3倍,再缩小到初始大小
        animator3.setDuration(5000);
        animator3.setRepeatCount(ValueAnimator.INFINITE);
        animator3.start();
    }
}
