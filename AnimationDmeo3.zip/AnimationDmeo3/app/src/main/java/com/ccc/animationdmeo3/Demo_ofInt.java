package com.ccc.animationdmeo3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Demo_ofInt extends AppCompatActivity {

    private Button mbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_of_int);

        mbutton = findViewById(R.id.anim1);
        mbutton.getLayoutParams().width = 250;

        //1. 设置属性数值的初始值 和 结束值
        // 结束值 = 500
        ValueAnimator valueAnimator = ValueAnimator.ofInt(mbutton.getLayoutParams().width,500);

        //2.设置动画的各种属性
        valueAnimator.setDuration(3000); //动画时长
        valueAnimator.setRepeatCount(ValueAnimator.INFINITE); //重复播放

        //3.将属性值手动赋值给对象的属性：此处是将 值 付给按钮的宽度
        //设置更新监听器，即数值每次变化更新都会调用该方法
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int currentValue = (Integer) animation.getAnimatedValue();
                System.out.println(currentValue);

                //每次值变化，将值手动赋值给对象的属性
                mbutton.getLayoutParams().width = currentValue;
                //4.刷新视图，即重新绘制，从而实现动画效果
                mbutton.requestLayout();
            }
        });

        //启动动画
        valueAnimator.start();
    }
}
