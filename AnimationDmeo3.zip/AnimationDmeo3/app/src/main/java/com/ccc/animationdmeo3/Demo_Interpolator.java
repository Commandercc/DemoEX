package com.ccc.animationdmeo3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.widget.Button;

public class Demo_Interpolator extends AppCompatActivity {

    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo__interpolator);

        button = findViewById(R.id.dec_accel);

        //获得按钮的当前位置
        float curTranslationX = button.getTranslationX();

        ObjectAnimator animator = ObjectAnimator.ofFloat(button,"translationX",curTranslationX,500,curTranslationX);
        // 创建动画对象 & 设置动画
        // 表示的是:
        // 动画作用对象是mButton
        // 动画作用的对象的属性是X轴平移
        // 动画效果是:从当前位置平移到 x=1500 再平移到初始位置

        animator.setDuration(5000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.start();
    }
}
