package com.ccc.animationdmeo3.objectDemo;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class MyView extends View {
    //设置需要用到的变量
    public static final float RADIUS = 100f; //半径
    private Point currentPoint; //当前坐标
    private Paint mPaint; //绘图画笔

    public MyView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        //初始化画笔
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.RED);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //如果当前坐标为空（即第一次）
        if (currentPoint == null) {
            //创建一个点对象(100,100)
            currentPoint = new Point(RADIUS, RADIUS);
            //在该点画一个圆
            float x = currentPoint.getX();
            float y = currentPoint.getY();
            canvas.drawCircle(x, y, RADIUS, mPaint);


            //将属性动画作用到View中
            //1. 创建初始动画的对象点 和 动画结束时的对象点
            Point startPoint = new Point(RADIUS, RADIUS); //初始（100,100）
            Point endPoint = new Point(700, 1000); //结束点（700,1000)

            //2.创建动画对象 设置初始值 和结束值
            ValueAnimator animator = ValueAnimator.ofObject(new PointEvaluator(), startPoint, endPoint);
            // 参数说明
            // 参数1：TypeEvaluator 类型参数 - 使用自定义的PointEvaluator(实现了TypeEvaluator接口)
            // 参数2：初始动画的对象点
            // 参数3：结束动画的对象点

            //3. 设置动画参数
            animator.setDuration(5000);
            animator.setRepeatCount(ValueAnimator.INFINITE);

            //4.通过 值 的更新监听器，将改变的对象手动赋值给当前对象
            // 此处是将 改变后的坐标值对象 赋给 当前的坐标值对象
            // 设置值的更新监听器，即每当坐标值更新一次，该方法就会被调用一次
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    //获取当前坐标值
                    currentPoint = (Point) animation.getAnimatedValue();
                    //重新绘制
                    // 调用invalidate()后,就会刷新View,即才能看到重新绘制的界面,即onDraw()会被重新调用一次
                    // 所以坐标值每改变一次,就会调用onDraw()一次
                    invalidate();
                }
            });

            animator.start();
        } else {
            //如果坐标值不为空 则画圆
            //所以坐标值每改变一次 就会调用onDraw() 一次，就会画一次圆，从而实现动画效果

            //在该点画一个圆
            float x = currentPoint.getX();
            float y = currentPoint.getY();
            canvas.drawCircle(x,y,RADIUS,mPaint);
        }
    }
}
